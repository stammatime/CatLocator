var axios = require('axios');
var Twit = require('twit');

consumerKey="luEaNQZKquAwSNHqeFw4PfLjH";
consumerSecret="9Fg8gyNy5Qhb70kNIUO3IhAWKUvkDyjuXcvlOCcb7OH5FYhlXE";
baseURL = "https://api.twitter.com";

function getSinkInfo(callback){

    var T = new Twit({
    consumer_key:         consumerKey,
    consumer_secret:      consumerSecret,
    app_only_auth:        true,
    timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests. 
    })
    var x;
    T.get('statuses/user_timeline', { screen_name: 'isacatinthesink', count: 1 }, (err, data, response) => {
    // console.log(data[0].created_at);
    // console.log(data[0].text);
    // console.log(data[0].entities.media[0].url);
    return callback(data[0]);
    })

}

exports.getSinkInfo = getSinkInfo;